# Police Escape

A browser-based 3D endless-runner prototype built with Three.js.

## Run locally
Open `index.html` in a modern browser with an internet connection. The game loads Three.js from a CDN.

## Publish with GitHub Pages
1. Create a public GitHub repository named `police-escape`.
2. Upload `index.html` and this `README.md` to the repository root.
3. In Settings → Pages, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
4. Wait for the Pages deployment to finish. Your site will be at `https://YOUR-USERNAME.github.io/police-escape/`.

This is an early prototype. It does not yet include accounts, cloud saves, a full character shop, or persistent unlocks.
